<?php return array (
  'create-user' => 'App\\Http\\Livewire\\CreateUser',
  'table.main' => 'App\\Http\\Livewire\\Table\\Main',
);