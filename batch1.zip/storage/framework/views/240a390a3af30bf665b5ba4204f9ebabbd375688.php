<?php
$user = auth()->user();
?>

<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <form class="form-inline mr-auto">
        <ul class="navbar-nav mr-3">
            <li><a href="#" data-turbolinks="false" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-list-ul"></i></a></li>
        </ul>
        
        
        <h5 class="font-weight-bold text-2xl text-white"><?php echo e(config('Sistem Informasi Monitoring Progres Pekerjaan Jalan dan Jembatan', 'Sistem Informasi Monitoring Progres Pekerjaan Jalan dan Jembatan')); ?></h5>
    </form>
    <ul class="navbar-nav navbar-right">
        <li class="dropdown"><a href="#" data-turbolinks="false" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
            <?php if(!is_null($user)): ?>
                <div class="d-sm-none d-lg-inline-block">Selamat datang , <?php echo e($user->name); ?></div></a>
            <?php else: ?>
                <div class="d-sm-none d-lg-inline-block">Hai, Welcome</div></a>
            <?php endif; ?>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="/user/profile" class="dropdown-item has-icon">
                    <i class="far fa-user"></i> Profile
                </a>
                <?php if(request()->get('is_admin')): ?>
                <a href="/setting" class="dropdown-item has-icon">
                    <i class="fas fa-cog"></i> Setting
                </a>
                <?php endif; ?>
                <div class="dropdown-divider"></div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <a href="<?php echo e(route('login')); ?>" class="dropdown-item has-icon text-danger" onclick="event.preventDefault();this.closest('form').submit();">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </form>
            </div>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\ujianwebbb\resources\views/components/navbar.blade.php ENDPATH**/ ?>