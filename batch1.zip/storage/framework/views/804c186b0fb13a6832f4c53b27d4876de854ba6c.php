<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h1>Daftar Kontraktor</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="dashboard">Daftar Kontraktor</a></div>
        </div>
     <?php $__env->endSlot(); ?>

    <a href="<?php echo e(route('createkontraktor')); ?>"><button class="btn btn-success">Tambah Data</button></a>
    <br>
    <br>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Nama Kontraktor</th>
            <th scope="col">Alamat</th>
            <th scope="col">No Hp/WhatsApp</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontraktor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($kontraktor->id); ?></td>
            <td><?php echo e($kontraktor->nama_kontraktor); ?></td>
            <td><?php echo e($kontraktor->alamat); ?></td>
            <td><?php echo e($kontraktor->no_hp); ?></td>
            <td>
                <a href="edit-kontraktor/<?php echo e($kontraktor->id); ?>"><button class="btn btn-warning">Edit</button></a>
                <a href="delete-kontraktor/<?php echo e($kontraktor->id); ?>"><button class="btn btn-danger">Hapus</button></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                </div>
                </div>
              </div>
            </div>
          </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\ujianwebjadiiiiiiiii\resources\views/kontraktor/daftar-kontraktor.blade.php ENDPATH**/ ?>