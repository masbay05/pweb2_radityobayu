<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header_content', null, []); ?> 
        <h1>Tambah Kontraktor</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="dashboard">Tambah Kontraktor</a></div>
        </div>
     <?php $__env->endSlot(); ?>
    <form action="<?php echo e(route('insertkontraktor')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                  <label>Nama Kontraktor</label>
                  <input type="text" name="nama_kontraktor" class="form-control" required="">
                </div>
                <div class="form-group">
                  <label>Alamat</label>
                  <input type="text" name="alamat" class="form-control" required="">
                </div>
                <div class="form-group">
                  <label>No Hp/WhatsApp</label>
                  <input type="text" name="no_hp" class="form-control">
                </div>
              </div>
              <div class="container-fluid">
                <div class="form-group">
                    <a href="/daftar-kontraktor"><button type="button" class="btn btn-warning">Kembali</button></a>&nbsp;
                    <button type="submit" class="btn btn-success">Tambah Data</button>
                  </div>
              </div>
        </div>
      </form>

    <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                </div>
                </div>
              </div>
            </div>
          </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ujianweb\resources\views/kontraktor/tambah-kontraktor.blade.php ENDPATH**/ ?>