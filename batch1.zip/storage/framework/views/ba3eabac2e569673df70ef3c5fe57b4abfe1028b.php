<?php
$links = [
    [
        "href" => "dashboard",
        "text" => "Menu",
        "is_multi" => false,
    ],
    [
        "href" => [
            [
                "section_text" => "Kelola Pengguna",
                "section_list" => [
                    ["href" => "user", "text" => "Data User"],
                    ["href" => "user.new", "text" => "Buat User"]
                ]
            ]
        ],
        "text" => "Pengguna",
        "is_multi" => true,
    ],
];
$navigation_links = array_to_object($links);
?>

<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <img src="<?php echo e(asset('asset/removebg.png')); ?>" alt="" width="200" heiht="200" >
        
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('dashboard')); ?>">
                <img class="d-inline-block" width="32px" height="30.61px" src="" alt="">
            </a>
        </div>
        <?php $__currentLoopData = $navigation_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="sidebar-menu">
            <li class="menu-header"><?php echo e($link->text); ?></li>
            <?php if(!$link->is_multi): ?>
            <li class="<?php echo e(Request::routeIs($link->href) ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route($link->href)); ?>"><i class="fas fa-desktop"></i><span>Dashboard</span></a>
            </li>
            <li class="<?php echo e(Request::routeIs('data.index') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('daftarkontraktor')); ?>"><i class="fas fa-address-card"></i><span>Data Kontraktor</span></a>
            </li>
            <?php else: ?>
                <?php $__currentLoopData = $link->href; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $routes = collect($section->section_list)->map(function ($child) {
                        return Request::routeIs($child->href);
                    })->toArray();

                    $is_active = in_array(true, $routes);
                    ?>

                    <li class="dropdown <?php echo e(($is_active) ? 'active' : ''); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-users"></i> <span><?php echo e($section->section_text); ?></span></a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $section->section_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e(Request::routeIs($child->href) ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route($child->href)); ?>"><?php echo e($child->text); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\pweb2_simonitoring\resources\views/components/sidebar.blade.php ENDPATH**/ ?>